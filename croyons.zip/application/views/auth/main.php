<?php  
echo 'halaman utama';
